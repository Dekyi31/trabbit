// package com.trabbitproject.habits.config;

// public class UserRegistrationRequest {

//     public String getUsername() {
//         return null;
//     }

//     public CharSequence getPassword() {
//         return null;
//     }

// }
