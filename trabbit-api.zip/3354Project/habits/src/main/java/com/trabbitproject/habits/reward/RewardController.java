package com.trabbitproject.habits.reward;

// import org.springframework.web.bind.annotation.RestController;
// import reactor.core.publisher.Flux;
// import org.bson.types.ObjectId;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.data.domain.Sort;
// import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.web.bind.annotation.PathVariable;
// import org.springframework.web.bind.annotation.RequestParam;


// @RestController
// public class RewardController {

//     @Autowired
//     private RewardService rewardService;

//     @GetMapping("/rewards/{userId}")
//     public Flux<Reward> getUserRewards(@PathVariable ObjectId userId, @RequestParam int page, @RequestParam int size, @RequestParam Sort.Direction direction, @RequestParam String... properties) {
//         return rewardService.getUserRewards(userId, size, size, direction, properties);
//     }

// }
