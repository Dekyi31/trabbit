package com.trabbitproject.habits;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HabitsApplicationTests {

	@Test
	void contextLoads() {
	}

}
